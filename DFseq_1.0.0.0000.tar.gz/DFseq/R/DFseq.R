#' A function for calculating the null distributions of the two standard deviations using permutation (under the null)
#'
#' This function calculates the null distributions of the two standard deviations using permutation (under the null).
#' @param raw0 raw data matrix
#' @param tn0 group id
#' @param n.permu number of permutations
#' @param n.gene number of genes
#' @param UD specifies whether up or down regulated genes to be evaluated
#' @param cutp to quantile to be estimated in a quantile regression
#' @param polyx degree of polynomial
#' @param main.t plot main title
#' @param ylab y axis label
#' @param rqmethod the algorithmic mehtod to be used in quantile regression
#' @param polyx.select whether to select the degree of polynomial
#' @param plotTF whether to generate a plot
#' @keywords differential expression, gene
#' @export
#' @examples
#' DFseq()
DFseq=function(raw_0, tn0, n.permu, n.gene, UD, cutp, ylab, main.t, rqmethod, polyx.select, plotTF)
{if (missing (ylab)) {ylab=""}
  if (missing (cutp)) {cutp=0.05}
  if (missing (polyx.select)) {polyx.select=FALSE}
  if (missing (rqmethod)) {rqmethod="fn"}
  if (missing (main.t)) {main.t=""}
  if (missing (plotTF)) {plotTF=TRUE}
  DFout=DF_SEQ(raw_0, tn0, n.permu, n.gene)

  if (UD=="UP") {out.null=DFout[[1]]}
  if (UD=="DN") {out.null=DFout[[3]]}
  if (UD=="UP") {out.Real=DFout[[2]]}
  if (UD=="DN") {out.Real=DFout[[4]]}
  out.null=out.null[order(out.null$xxx),]
  out.null$int=out.null$xxx*out.null$status
  out.Real$int=out.Real$xxx*out.Real$status
  sel.polyx=5
  if (max(table(out.null$status))>(.99*nrow(out.null)))
    {fit1x = rq(yyy~bs(xxx+status+int, degree=sel.polyx), method=rqmethod, tau = cutp,  data=out.null)} else
    {fit1x = rq(yyy~bs(xxx           , degree=sel.polyx), method=rqmethod, tau = cutp,  data=out.null)}

  if (polyx.select)
  {for (polyx in 6:12)
    if (max(table(out.null$status))>(.99*nrow(out.null)))
      {fit1x0 <- rq(yyy~bs(xxx+status+int, degree=polyx), method=rqmethod, tau = cutp,  data=out.null)
      if (glance(fit1x0)[[3]]<glance(fit1x)[[3]]) {fit1x=fit1x0
      sel.polyx=polyx}
      } else
      {fit1x0 <- rq(yyy~bs(xxx           , degree=polyx), method=rqmethod, tau = cutp,  data=out.null)
      if (glance(fit1x0)[[3]][1]<glance(fit1x)[[3]][1]) {fit1x=fit1x0
      sel.polyx=polyx}
      }
  }


  rxxR=predict(fit1x, data.frame(xxx=out.Real$xxx, status=out.Real$status, int=out.Real$int))
  rxx=predict(fit1x, data.frame(xxx=out.null$xxx, status=out.null$status, int=out.null$int))
  TF=as.data.frame(out.Real$yyy<rxxR)
  row.names(TF)=row.names(out.Real)

  if (plotTF)
  {plot(out.null$xxx, out.null$yyy, cex=.1,xlim=c(min(c(out.null$xxx, out.Real$xxx)), max(c(out.null$xxx, out.Real$xxx))), ylim=c(min(c(out.null$yyy, out.Real$yyy)), max(c(out.null$yyy, out.Real$yyy))),main=main.t, xlab="SD of log2(U1+Y)", ylab=ylab)
    points(out.Real$xxx, out.Real$yyy, cex=.2, col=3)

    points(out.Real$xxx[out.Real$yyy<rxxR], out.Real$yyy[out.Real$yyy<rxxR], cex=.5, col=2)
  }

  return(as.matrix(TF))
}
