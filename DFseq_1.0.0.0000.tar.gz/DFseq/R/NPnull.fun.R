#' A function for calculating standard deviations under the null, using permutation
#'
#' This function calculates standard deviations under the null, using permutation.
#' @param raw0 raw data matrix
#' @param tni group id
#' @keywords null distribution, permutation
#' @export
#' @examples
#' NPnull.fun()
NPnull.fun=function(raw0, tni)
{ tn=tni[!is.na(tni)]
tn[sample(seq(1,length(tn)), sum(tni==FALSE))]=FALSE
UpnDown=UD.fun(raw0, tn)
kku=raw0

t_index=which(tn==TRUE)
n_index=which(tn==FALSE)

rua=matrix(runif(dim(kku)[[1]]*dim(kku)[[2]], -.5, .5), ncol=dim(kku)[[2]])
kku=raw0+rua
cc=rowSums(kku[,n_index])/length(n_index)
to.Beta=function (x, cc) {x/(x+cc)}
BB=apply(kku, 2, to.Beta, cc=cc)
Bm=apply(BB[,t_index], 1, mean)
Bsd=apply(BB[,t_index], 1, sd)
lmm=apply(log2(kku)[,t_index], 1, mean)
lmsd=apply(log2(kku)[,t_index], 1, sd)

qmy=apply(raw0[,t_index], 1, mean)
qsdy=apply(raw0[,t_index], 1, sd)
sdmratio=qsdy/qmy

out=data.frame(xxx=lmsd, yyy=Bsd, UD=UpnDown, rm=lmm, ratio=sdmratio)

return(out)
}
