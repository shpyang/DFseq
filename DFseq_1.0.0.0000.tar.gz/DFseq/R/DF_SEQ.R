#' A function for generate the distributions of two standard deviations under both the null and real, for up and down regulated genes
#'
#' This function generate the distributions of two standard deviations under both the null and real, for up and down regulated genes.
#' @param raw0 raw data matrix
#' @param tn0 group id
#' @param n.permu number of permutations
#' @param n.gene number of genes
#' @param plotTF whether to generate a plot
#' @param main.t plot main title
#' @keywords standard deviations, null, real data, up-regulated, down-regulated
#' @export
#' @examples
#' DF_SEQ()
DF_SEQ=function(raw_0, tn0, n.permu, n.gene)
{ if (missing(n.permu)) {n.permu=1000}
  if (missing(n.gene)) {n.gene=100}

  n_index = which(tn0==TRUE)
  t_index = which(tn0==FALSE)

  sum.m=function (x) {sum(x==0)}
  E0=as.vector(apply(raw_0, 1, sum.m))
  raw0r=t(apply(raw_0, 1, rank))
  raw0=raw0r

  ikk=length(tn0)*.2

  rawx=raw0[E0<=ikk,]
  rawxn=raw0[E0>ikk,]

  outx=NPN.fun(rawx, tn=tn0, n.permu=n.permu)
  outUPx=outx[[1]]
  outDNx=outx[[2]]
  outrx=NPT.fun(rawx, tn=tn0)
  outrUPx=outrx[[1]]
  outrDNx=outrx[[2]]

  if (nrow(rawxn)>0)
    {outxn=NPN.fun(rawxn, tn=tn0, n.permu=n.permu)
     outrxn=NPT.fun(rawxn, tn=tn0)
     outUPxn=outxn[[1]]
     outDNxn=outxn[[2]]
     outrUPxn=outrxn[[1]]
     outrDNxn=outrxn[[2]]
    }  else
    {outUPxn=outUPx[1,]
     outrUPxn=outrUPx[1,]
     outDNxn=outDNx[1,]
     outrDNxn=outrDNx[1,]
    }

  up.null=rbind(cbind(outUPx, status=2), cbind(outUPxn, status=1))
  up.Real=rbind(cbind(outrUPx, status=2), cbind(outrUPxn, status=1))
  dn.null=rbind(cbind(outDNx, status=2), cbind(outDNxn, status=1))
  dn.Real=rbind(cbind(outrDNx, status=2), cbind(outrDNxn, status=1))
  if (nrow(rawxn)==0) {up.null=up.null[-nrow(up.null),]
                        up.Real=up.Real[-nrow(up.Real),]
                        dn.null=dn.null[-nrow(dn.null),]
                        dn.Real=dn.Real[-nrow(dn.Real),]}

  out=list(up.null, up.Real, dn.null, dn.Real)
  names(out)=c("up.null", "up.Real", "dn.null", "dn.Real")

  return(out)
}
