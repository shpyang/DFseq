#' A function for calculating standard deviations for the two constructed variables
#'
#' This function calculates standard deviations for the two constructed variables.
#' @param raw0 raw data matrix
#' @param tni group id
#' @keywords null distribution, permutation
#' @export
#' @examples
#' gSDs.fun()
gSDs.fun=function(raw0, tni)
{UpnDown=UD.fun(raw0, tni)
kku=raw0

t_index=which(tni==TRUE)
n_index=which(tni==FALSE)

rua=matrix(runif(dim(kku)[[1]]*dim(kku)[[2]], -.5, .5), ncol=dim(kku)[[2]])
kku=raw0+rua
cc=rowSums(kku[,n_index])/length(n_index)
to.Beta=function (x, cc) {x/(x+cc)}
BB=apply(kku, 2, to.Beta, cc=cc)
Bm=apply(BB[,t_index], 1, mean)
Bsd=apply(BB[,t_index], 1, sd)
lmm=apply(log2(kku)[,t_index], 1, mean)
lmsd=apply(log2(kku)[,t_index], 1, sd)

qmy=apply(raw0[,t_index], 1, mean)
qsdy=apply(raw0[,t_index], 1, sd)
sdmratio=qsdy/qmy

out=data.frame(xxx=lmsd, yyy=Bsd, UD=UpnDown, rm=lmm, ratio=sdmratio)

return(out)
}
