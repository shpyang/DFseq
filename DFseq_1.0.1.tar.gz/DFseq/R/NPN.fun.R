#' A function for calculating the null distributions of the two standard deviations using permutation (under the null)
#'
#' This function calculates the null distributions of the two standard deviations using permutation (under the null).
#' @param raw0 raw data matrix
#' @param tni group id
#' @param n.permu number of permutations
#' @param n.gene number of genes
#' @keywords constructed random variables, standard deviation, null
#' @export
#' @examples
#' NPN.fun()
NPN.fun=function (raw0, tni, n.permu, n.gene)
{ if (missing(n.gene)) {n.gene=100}
  if (missing(n.permu)) {n.permu=1000}
  for (i in 1:n.permu)
  {sampls=sample(1:(dim(raw0)[[1]]), min(n.gene, dim(raw0)[[1]]))
  rawi=as.matrix(raw0[sampls,])

  tn=rep(1, length(tni))
  tn[sample(seq(1,length(tn)), sum(tni==FALSE))]=FALSE
  
  outiw=gSDs.fun(rawi, tn)
  if (i==1)
  {outi=outiw} else
  {outi=rbind(outi, outiw)}
  }

  outi=outi[!is.na(outi$xxx),]
up.gene=outi[outi$UD=="UP",]
dn.gene=outi[outi$UD=="DN",]
  return(list(up.gene, dn.gene))
}
