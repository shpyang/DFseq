#' A function for checking which group has larger average
#'
#' This function checks which group has larger average.
#' @param raw0 raw data matrix
#' @param tn group id
#' @keywords compare, mean
#' @export
#' @examples
#' UD.fun()
UD.fun=function(raw0, tn)
{ t_index=which(tn==TRUE)
n_index=which(tn!=TRUE)

raw0T=raw0[,t_index]
raw0C=raw0[,n_index]
meanT=rowSums(raw0T)/dim(raw0T)[[2]]
meanC=rowSums(raw0C)/dim(raw0C)[[2]]
meanT=rowMedians(raw0T)
meanC=rowMedians(raw0C)

out=rep("UP", nrow(raw0))

out[meanT<meanC]="DN"

return(out)
}
