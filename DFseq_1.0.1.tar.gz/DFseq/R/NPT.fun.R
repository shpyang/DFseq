#' A function for calculating standard deviations of the two constructed random variables under the real
#'
#' This function calculates standard deviations of the two constructed random variables under the real.
#' @param raw0 raw data matrix
#' @param tni group id
#' @param updn specifies whether up or down regulated
#' @param plotTF whether to generate a plot
#' @param main.t plot main title
#' @keywords constructed random variables, standard deviation, real data
#' @export
#' @examples
#' NPT.fun()
NPT.fun=function(raw0, tni)
{ outi =gSDs.fun(raw0, tni)
  outi=outi[!is.na(outi$xxx),]
  up.gene=outi[outi$UD=="UP",]
  dn.gene=outi[outi$UD=="DN",]
  return(list(up.gene, dn.gene))

}
